import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';

interface LapTime {
  index: number;
  text: string;
  timestamp: number;
}

interface RecordsScreenProps {
  lapTimes: LapTime[];
  handleRenameLap: (index: number) => void;
}

const RecordsScreen: React.FC<RecordsScreenProps> = ({
  lapTimes,
  handleRenameLap,
}) => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Lap Times</Text>
      <View style={styles.listContainer}>
        {lapTimes.length === 0 ? (
          <Text style={styles.noRecordsText}>No lap records</Text>
        ) : (
          lapTimes.map((lap) => (
            <TouchableOpacity
              key={lap.index}
              style={styles.lapButton}
              onPress={() => handleRenameLap(lap.index)}
            >
              <Text style={styles.lapButtonText}>
                {lap.text} - {lap.timestamp}s
              </Text>
            </TouchableOpacity>
          ))
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  listContainer: {
    width: '80%',
  },
  noRecordsText: {
    fontSize: 16,
    fontStyle: 'italic',
    textAlign: 'center',
  },
  lapButton: {
    backgroundColor: '#e0e0e0',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    marginBottom: 10,
  },
  lapButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default RecordsScreen;
