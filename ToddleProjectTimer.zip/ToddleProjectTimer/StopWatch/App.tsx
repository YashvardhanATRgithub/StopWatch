import { StatusBar } from 'expo-status-bar';
import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, TouchableOpacity, View, ScrollView, Modal, TextInput, Button, SafeAreaView } from 'react-native';

import RecordsScreen from './RecordsScreen';

export default function App() {
  const [isRunning, setIsRunning] = useState(false);
  const [buttonText, setButtonText] = useState('Start');
  const [time, setTime] = useState(0);
  const [lapTimes, setLapTimes] = useState<{ index: number; text: string; timestamp: number }[]>([]);
  const [activeScreen, setActiveScreen] = useState('timer');
  const [resetButtonVisible, setResetButtonVisible] = useState(false);
  const [selectedLapIndex, setSelectedLapIndex] = useState(-1);
  const [newLapName, setNewLapName] = useState('');
  const [modalVisible, setModalVisible] = useState(false);

  let interval: NodeJS.Timeout | null = null;

  useEffect(() => {
    if (isRunning) {
      interval = setInterval(() => {
        setTime((prevTime) => prevTime + 1);
      }, 1000);
    } else {
      clearInterval(interval!);
      interval = null;
    }

    return () => {
      clearInterval(interval!);
    };
  }, [isRunning]);

  const handleStartStop = () => {
    if (isRunning) {
      setIsRunning(false);
      setButtonText('Resume');
      setResetButtonVisible(true);
    } else {
      if (time === 0) {
        setLapTimes([]);
      }
      setIsRunning(true);
      setButtonText('Stop');
      setResetButtonVisible(false);
    }
  };

  const handleLap = () => {
    if (!isRunning) {
      return;
    }

    const newLap = {
      index: lapTimes.length + 1,
      text: `Lap ${lapTimes.length + 1}`,
      timestamp: time,
    };
    setLapTimes((prevLapTimes) => [...prevLapTimes, newLap]);
  };

  const handleReset = () => {
    setIsRunning(false);
    setButtonText('Start');
    setResetButtonVisible(false);
    setTime(0);
    setLapTimes([]);
  };

  const cancelRenameLap = () => {
    setModalVisible(false);
    setSelectedLapIndex(-1);
    setNewLapName('');
  };

  const formatTime = (timeInSeconds: number) => {
    const hours = Math.floor(timeInSeconds / 3600);
    const minutes = Math.floor((timeInSeconds % 3600) / 60);
    const seconds = timeInSeconds % 60;

    const formattedHours = String(hours).padStart(2, '0');
    const formattedMinutes = String(minutes).padStart(2, '0');
    const formattedSeconds = String(seconds).padStart(2, '0');

    return `${formattedHours}:${formattedMinutes}:${formattedSeconds}`;
  };

  const handleRenameLap = (index: number) => {
    const selectedLap = lapTimes.find((lap) => lap.index === index);
    if (selectedLap) {
      setSelectedLapIndex(index);
      setNewLapName(selectedLap.text);
      setModalVisible(true);
    }
  };

  const saveRenamedLap = () => {
    if (selectedLapIndex !== -1) {
      const updatedLapTimes = lapTimes.map((lap) => {
        if (lap.index === selectedLapIndex) {
          return { ...lap, text: newLapName };
        }
        return lap;
      });
      setLapTimes(updatedLapTimes);
    }
    cancelRenameLap();
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="auto" />

      <View style={styles.header}>
        <TouchableOpacity onPress={() => setActiveScreen('timer')} style={styles.tabButton}>
          <Text style={[styles.tabButtonText, activeScreen === 'timer' && styles.activeTabButtonText]}>Timer</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => setActiveScreen('records')} style={styles.tabButton}>
          <Text style={[styles.tabButtonText, activeScreen === 'records' && styles.activeTabButtonText]}>Records</Text>
        </TouchableOpacity>
      </View>

      {activeScreen === 'timer' ? (
        <View style={styles.timerContainer}>
          <Text style={styles.timerText}>{formatTime(time)}</Text>

          <TouchableOpacity style={styles.button} onPress={handleStartStop}>
            <Text style={styles.buttonText}>{buttonText}</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.button} onPress={handleLap}>
            <Text style={styles.buttonText}>Lap</Text>
          </TouchableOpacity>

          {resetButtonVisible && (
            <TouchableOpacity style={styles.button} onPress={handleReset}>
              <Text style={styles.buttonText}>Reset</Text>
            </TouchableOpacity>
          )}
        </View>
      ) : (
        <RecordsScreen lapTimes={lapTimes} handleRenameLap={handleRenameLap} />
      )}

      <Modal visible={modalVisible} animationType="slide">
        <View style={styles.modalContainer}>
          <TextInput
            style={styles.input}
            value={newLapName}
            onChangeText={setNewLapName}
            placeholder="Enter lap name"
          />

          <View style={styles.modalButtonContainer}>
            <Button title="Save" onPress={saveRenamedLap} />
            <Button title="Cancel" onPress={cancelRenameLap} />
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingTop: 20,
    paddingBottom: 10,
    backgroundColor: 'lightblue',
    elevation: 2,
  },
  tabButton: {
    paddingHorizontal: 15,
    paddingVertical: 30,
  },
  tabButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'gray',
  },
  activeTabButtonText: {
    color: 'black',
  },
  timerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20, // Add this line
  },
  timerText: {
    fontSize: 50,
    fontWeight: 'bold',
  },
  button: {
    marginVertical: 10,
    paddingHorizontal: 30,
    paddingVertical: 15,
    backgroundColor: 'lightblue',
    borderRadius: 5,
  },
  buttonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  input: {
    width: '80%',
    height: 40,
    borderBottomWidth: 1,
    marginBottom: 20,
  },
  modalButtonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '60%',
  },
});
